ORKA ENGINE – Phase 2 Patch Paketi

Bu paket mevcut HTML dosyana doğrudan uygulanacak ilk ORKA veri katmanını içerir.

Ne çözer?
- HTML dosyasını file:// olarak açınca /api/fvt adresinin file:///C:/api/fvt gibi yanlış yorumlanmasını engeller.
- /api/fvt, /api/tefas ve /api/yahoo çağrılarını merkezi ORKA fetch katmanından geçirir.
- GET çağrılarında 2 deneme yapar.
- Başarılı GET cevaplarını localStorage cache’e alır.
- API geçici hata verirse son cache’i kullanmaya çalışır.

Dosyalar:
1) ORKA_ENGINE_PHASE2_PATCH.js
   HTML’e manuel eklenecek JavaScript bloğu.

2) apply_orka_phase2_patch.py
   HTML dosyasına patch’i otomatik ekleyen küçük Python aracı.

En kolay kullanım:
1) apply_orka_phase2_patch.py dosyasını index.html ile aynı klasöre koy.
2) Komut satırında:
   python apply_orka_phase2_patch.py index.html
3) Oluşan index_ORKA_PHASE2.html dosyasını aç.
4) HTML içinde ORKA_API_BASE değerini kendi Vercel adresinle değiştir.

Alternatif:
Tarayıcı konsolunda bir kez şu komutu çalıştır:
ORKA.setApiBase('https://fon-takip-sistemi.vercel.app')

Önemli:
Vercel domaini https://fon-takip-sistemi.vercel.app olarak ayarlandı.
