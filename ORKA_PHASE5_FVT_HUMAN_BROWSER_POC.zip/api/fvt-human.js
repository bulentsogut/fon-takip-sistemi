// ORKA ENGINE Phase 5 — FVT Human Browser Engine POC
// Route: /api/fvt-human?code=DFI
// Amaç: FVT sitesini gerçek tarayıcı gibi açıp Portföy Dağılımı ekranında görünen metni okumak.

const chromiumPack = require('@sparticuz/chromium');
const { chromium } = require('playwright-core');

function cleanCode(value) {
  return String(value || '')
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '')
    .slice(0, 12);
}

function parsePercent(value) {
  if (value === null || value === undefined) return null;
  const s = String(value)
    .replace('%', '')
    .replace(/\s+/g, '')
    .replace(',', '.')
    .trim();
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

function looksPercent(value) {
  return /-?\d+[,.]?\d*\s*%/.test(String(value || ''));
}

function isTickerLine(line) {
  const s = String(line || '').trim();
  if (!/^[A-Z0-9]{2,12}$/.test(s)) return false;
  const blocked = new Set([
    'PRO', 'ETF', 'BES', 'KAP', 'KVKK', 'BYF', 'FVT', 'BIST', 'TEFAS',
    'ANA', 'MENU', 'AKADEMI', 'TUMU'
  ]);
  return !blocked.has(s);
}

function isCategory(line) {
  const s = String(line || '').trim();
  return [
    'Yerli Hisseler',
    'Yabancı Hisseler',
    'BYF / Fonlar',
    'BYF/Fonlar',
    'Fonlar',
    'Döviz',
    'Altın',
    'Mevduat',
    'Diğer'
  ].includes(s);
}

function normalizeCategory(line) {
  const s = String(line || '').trim();
  if (s === 'BYF/Fonlar') return 'BYF / Fonlar';
  return s || '';
}

function parseHoldingsFromText(text) {
  const rawLines = String(text || '')
    .split(/\r?\n/)
    .map((x) => x.trim())
    .filter(Boolean);

  const start = rawLines.findIndex((line) => /Varlık\s+Fiyat\s+Getiri/i.test(line));
  const endHeat = rawLines.findIndex((line) => /GÜNCEL\s+ISI\s+HARİTASI/i.test(line));
  const endFooter = rawLines.findIndex((line) => /Piyasaları her yerden takip edin/i.test(line));

  const from = start >= 0 ? start + 1 : 0;
  let to = rawLines.length;
  if (endHeat > from) to = endHeat;
  else if (endFooter > from) to = endFooter;

  const lines = rawLines.slice(from, to);
  const holdings = [];
  let category = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    if (isCategory(line)) {
      category = normalizeCategory(line);
      continue;
    }

    if (!isTickerLine(line)) continue;

    // FVT görünür tablo yapısı genellikle:
    // CODE, price, return%, weight%, previous%, diff%
    const price = lines[i + 1] || '';
    const changeLine = lines[i + 2] || '';
    const weightLine = lines[i + 3] || '';
    const previousLine = lines[i + 4] || '';
    const diffLine = lines[i + 5] || '';

    if (!looksPercent(changeLine) || !looksPercent(weightLine)) continue;

    const weight = parsePercent(weightLine);
    if (weight === null) continue;

    holdings.push({
      code: line,
      symbol: line,
      priceText: price,
      change: parsePercent(changeLine),
      weight,
      previousWeight: parsePercent(previousLine),
      diff: parsePercent(diffLine),
      category
    });

    i += 5;
  }

  return holdings;
}

async function launchBrowser() {
  const executablePath = await chromiumPack.executablePath();
  return chromium.launch({
    args: chromiumPack.args,
    executablePath,
    headless: chromiumPack.headless,
  });
}

async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  const code = cleanCode(req.query.code || req.query.fon || 'TLY');
  if (!code) {
    res.status(400).json({ ok: false, error: 'Fon kodu eksik' });
    return;
  }

  const url = `https://fvt.com.tr/fonlar/yatirim-fonlari/${code}`;
  const startedAt = Date.now();
  let browser;
  const interestingResponses = [];

  try {
    browser = await launchBrowser();
    const context = await browser.newContext({
      locale: 'tr-TR',
      timezoneId: 'Europe/Istanbul',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',
      viewport: { width: 1365, height: 768 }
    });

    const page = await context.newPage();

    page.on('response', async (response) => {
      const rurl = response.url();
      if (/distribution|portfolio|holding|funds|app-token/i.test(rurl)) {
        interestingResponses.push({
          status: response.status(),
          url: rurl.slice(0, 300)
        });
      }
    });

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
    await page.waitForLoadState('networkidle', { timeout: 25000 }).catch(() => {});

    // İnsan gibi Portföy Dağılımı sekmesine tıkla. Görünüyorsa tıklar; zaten açıksa sorun olmaz.
    const tab = page.getByText('Portföy Dağılımı', { exact: true }).first();
    if (await tab.count().catch(() => 0)) {
      await tab.click({ timeout: 8000 }).catch(() => {});
      await page.waitForTimeout(2500);
    }

    // Metin içinde tablo oluşana kadar kısa bekleme.
    await page.waitForFunction(() => {
      const t = document.body && document.body.innerText ? document.body.innerText : '';
      return t.includes('Varlık') && t.includes('Ağırlık') && /\b[A-Z0-9]{2,12}\b/.test(t);
    }, { timeout: 20000 }).catch(() => {});

    const bodyText = await page.evaluate(() => document.body.innerText || '');
    const holdings = parseHoldingsFromText(bodyText);

    const title = await page.title().catch(() => '');
    const tableFound = bodyText.includes('Varlık') && bodyText.includes('Ağırlık');

    res.status(200).json({
      ok: holdings.length > 0,
      provider: 'fvt-human-browser',
      phase: 'ORKA_ENGINE_PHASE_5_POC',
      code,
      url,
      title,
      tableFound,
      count: holdings.length,
      holdings,
      debug: {
        elapsedMs: Date.now() - startedAt,
        interestingResponses,
        textSample: bodyText.slice(0, 4000)
      }
    });
  } catch (error) {
    res.status(500).json({
      ok: false,
      provider: 'fvt-human-browser',
      phase: 'ORKA_ENGINE_PHASE_5_POC',
      code,
      url,
      error: error && error.message ? error.message : String(error),
      elapsedMs: Date.now() - startedAt
    });
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

module.exports = handler;
