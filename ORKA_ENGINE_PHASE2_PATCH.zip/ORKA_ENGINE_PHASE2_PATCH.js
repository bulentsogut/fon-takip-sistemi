/*
  ORKA ENGINE – Phase 2 Patch
  Amaç:
  - HTML file:// olarak açıldığında /api/... çağrılarının file:///C:/api/... olmasını engeller.
  - Tüm /api/tefas, /api/yahoo, /api/fvt çağrılarını merkezi ORKA katmanından geçirir.
  - GET isteklerinde basit retry + cache fallback uygular.
  Kullanım:
  1) Bu bloğu HTML içinde ilk <script> bloğundan önce, tercihen </head> öncesine ekle.
  2) ORKA_API_BASE değerini kendi Vercel adresinle değiştir.
*/

(function(){
  'use strict';

  var ORKA_API_BASE = 'https://YOUR-VERCEL-PROJECT.vercel.app';

  function cleanBase(base){
    return String(base || '').replace(/\/+$/, '');
  }

  function getApiBase(){
    var saved = '';
    try { saved = localStorage.getItem('ORKA_API_BASE') || ''; } catch(e) {}
    var base = saved || ORKA_API_BASE || '';
    base = cleanBase(base);

    if (base.indexOf('YOUR-VERCEL-PROJECT') >= 0) {
      console.warn('[ORKA] ORKA_API_BASE henüz gerçek Vercel adresinle değiştirilmemiş.');
      return '';
    }
    return base;
  }

  function isApiPath(url){
    return typeof url === 'string' && /^\/api\//i.test(url);
  }

  function normalizeUrl(input){
    if (!isApiPath(input)) return input;

    var protocol = (window.location && window.location.protocol) || '';
    var isLocalFile = protocol === 'file:';
    var isLocalhost = window.location && /^(localhost|127\.0\.0\.1)$/i.test(window.location.hostname || '');

    // Yayın ortamında relative /api korunur.
    if (!isLocalFile && !isLocalhost) return input;

    var base = getApiBase();
    if (!base) return input;
    return base + input;
  }

  function cacheKey(url, options){
    var method = (options && options.method ? options.method : 'GET').toUpperCase();
    return 'ORKA_CACHE::' + method + '::' + url;
  }

  function readCache(key, maxAgeMs){
    try {
      var raw = localStorage.getItem(key);
      if (!raw) return null;
      var obj = JSON.parse(raw);
      if (!obj || !obj.ts) return null;
      if (maxAgeMs && Date.now() - obj.ts > maxAgeMs) return null;
      return obj;
    } catch(e) { return null; }
  }

  function writeCache(key, text, status, headersObj){
    try {
      localStorage.setItem(key, JSON.stringify({
        ts: Date.now(),
        status: status || 200,
        text: text,
        headers: headersObj || {}
      }));
    } catch(e) {}
  }

  function responseFromCache(cached){
    return new Response(cached.text || '', {
      status: cached.status || 200,
      headers: Object.assign({'Content-Type':'application/json','X-ORKA-Cache':'HIT'}, cached.headers || {})
    });
  }

  function cloneHeaders(headers){
    var out = {};
    try {
      headers.forEach(function(v,k){ out[k] = v; });
    } catch(e) {}
    return out;
  }

  var nativeFetch = window.fetch.bind(window);

  async function orkaFetch(input, options){
    var originalUrl = (typeof input === 'string') ? input : (input && input.url);
    var finalInput = input;

    if (typeof input === 'string') {
      finalInput = normalizeUrl(input);
    } else if (input && input.url && isApiPath(input.url)) {
      finalInput = new Request(normalizeUrl(input.url), input);
    }

    var method = (options && options.method ? options.method : (input && input.method) || 'GET').toUpperCase();
    var isGet = method === 'GET';
    var key = isGet ? cacheKey(String(finalInput && finalInput.url ? finalInput.url : finalInput), options) : null;
    var attempts = isGet ? 2 : 1;
    var lastErr = null;

    for (var i=0; i<attempts; i++) {
      try {
        var resp = await nativeFetch(finalInput, options);
        if (resp && resp.ok && isGet && key) {
          var copy = resp.clone();
          copy.text().then(function(txt){
            writeCache(key, txt, resp.status, cloneHeaders(resp.headers));
          }).catch(function(){});
        }
        return resp;
      } catch(e) {
        lastErr = e;
        await new Promise(function(resolve){ setTimeout(resolve, 450 * (i+1)); });
      }
    }

    if (isGet && key) {
      var cached = readCache(key, 1000 * 60 * 60 * 24);
      if (cached) {
        console.warn('[ORKA] API hata verdi, cache kullanıldı:', originalUrl || finalInput);
        return responseFromCache(cached);
      }
    }

    throw lastErr || new Error('ORKA fetch failed');
  }

  window.fetch = orkaFetch;

  window.ORKA = window.ORKA || {};
  window.ORKA.apiBase = getApiBase;
  window.ORKA.setApiBase = function(base){
    try { localStorage.setItem('ORKA_API_BASE', cleanBase(base)); } catch(e) {}
    console.log('[ORKA] API base kaydedildi:', cleanBase(base));
  };
  window.ORKA.url = normalizeUrl;
  window.ORKA.fetch = orkaFetch;

  console.log('[ORKA] Phase 2 fetch layer aktif. API base:', getApiBase() || '(relative/local)');
})();
