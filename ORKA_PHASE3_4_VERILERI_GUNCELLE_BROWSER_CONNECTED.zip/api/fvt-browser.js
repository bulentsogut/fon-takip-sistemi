// ORKA ENGINE Phase 3.2 — Vercel Browser Provider
// Endpoint:
//   /api/fvt-browser?codes=TLY,PHE,IJC,CPT
//   /api/fvt-browser?code=TLY
//
// Amaç:
// Vercel içinde gerçek Chromium çalıştırıp FVT sayfasını açar,
// ardından aynı browser context içinden distribution JSON'unu çeker.

const chromium = require("@sparticuz/chromium");
const playwright = require("playwright-core");

function cleanCode(v) {
  return String(v || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 12);
}

function parseCodes(req) {
  const raw = req.query.codes || req.query.code || req.query.kod || req.query.fon || "TLY";
  return String(raw)
    .split(",")
    .map(cleanCode)
    .filter(Boolean)
    .filter((x, i, a) => a.indexOf(x) === i)
    .slice(0, 8);
}

function n(v) {
  if (v === null || v === undefined || v === "") return 0;
  if (typeof v === "number") return Number.isFinite(v) ? v : 0;
  const x = Number(String(v).replace("%", "").replace(",", ".").trim());
  return Number.isFinite(x) ? x : 0;
}

function normalizeItem(it) {
  const code = String(it.hisseKodu || it.code || it.kod || "").trim().toUpperCase();
  const isFund = !!String(it.fonAdi2 || "").trim();
  let type = "bist";
  if (isFund) type = "fund";
  if (it.yabanci === 1 || it.yabanci === "1") type = "us";
  if (it.etf === 1 || it.etf === "1") type = "fund";

  return {
    code,
    name: String(it.sirketAdi || it.fonAdi2 || it.name || code).trim(),
    weight: n(it.agirlik ?? it.value ?? it.weight),
    oldWeight: n(it.eskiAgirlik),
    diff: n(it.fark),
    change: n(it.degisimCanli ?? it.degisim ?? it.oranCanli ?? it.oran),
    type,
    sector: String(it.sektorAdi || "").trim()
  };
}

async function launchBrowser() {
  return playwright.chromium.launch({
    args: chromium.args,
    executablePath: await chromium.executablePath(),
    headless: chromium.headless
  });
}

async function fetchFundInBrowser(page, code) {
  const pageUrl = `https://fvt.com.tr/fonlar/yatirim-fonlari/${encodeURIComponent(code)}`;
  await page.goto(pageUrl, { waitUntil: "domcontentloaded", timeout: 45000 });

  // FVT bazı token/cookie süreçlerini JS ile tamamlıyor. Kısa bekleme çok işe yarıyor.
  await page.waitForTimeout(1200);

  const result = await page.evaluate(async (code) => {
    function makeDeviceId() {
      let id = localStorage.getItem("orka_fvt_device_id");
      if (!id) {
        id = Math.random().toString(16).slice(2, 10) + Date.now().toString(16).slice(-8);
        localStorage.setItem("orka_fvt_device_id", id);
      }
      return id;
    }

    async function readJson(url, deviceId) {
      const r = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: {
          "accept": "application/json, text/plain, */*",
          "x-device-id": deviceId
        }
      });
      const text = await r.text();
      let json = null;
      try { json = JSON.parse(text); } catch (e) {}
      return { ok: r.ok && !!json, status: r.status, json, preview: text.slice(0, 220) };
    }

    const deviceId = makeDeviceId();

    // App token akışı
    let appToken = null;
    try {
      appToken = await readJson("/api/app-token", deviceId);
    } catch (e) {
      appToken = { ok: false, error: e.message };
    }

    const distribution = await readJson(`/api/funds/${encodeURIComponent(code)}/distribution`, deviceId);

    let assetChart = null;
    try {
      assetChart = await readJson(`/api/funds/${encodeURIComponent(code)}/asset-chart`, deviceId);
    } catch (e) {
      assetChart = { ok: false, error: e.message };
    }

    return { deviceId, appToken, distribution, assetChart };
  }, code);

  const distJson = result.distribution && result.distribution.json;
  const data = distJson && distJson.data ? distJson.data : {};
  const items = Array.isArray(data.items) ? data.items : [];
  const holdings = items.map(normalizeItem).filter((x) => x.code);

  return {
    ok: result.distribution && result.distribution.ok && holdings.length > 0,
    code,
    holdings,
    aciklamaTarihi: data.meta && data.meta.aciklamaTarihi ? data.meta.aciklamaTarihi : "",
    meta: data.meta || {},
    assetChart: result.assetChart && result.assetChart.json ? result.assetChart.json : null,
    browser: {
      deviceId: result.deviceId,
      appTokenOk: !!(result.appToken && result.appToken.ok),
      distributionStatus: result.distribution ? result.distribution.status : null,
      assetChartStatus: result.assetChart ? result.assetChart.status : null,
      distributionPreview: result.distribution ? result.distribution.preview : ""
    }
  };
}

module.exports = async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "s-maxage=300, stale-while-revalidate=900");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  const startedAt = new Date().toISOString();
  const codes = parseCodes(req);

  if (!codes.length) {
    res.status(400).json({ ok: false, source: "orka-vercel-browser-provider", error: "missing code" });
    return;
  }

  let browser;
  const funds = {};
  const errors = [];

  try {
    browser = await launchBrowser();
    const page = await browser.newPage({
      userAgent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
      viewport: { width: 1366, height: 768 },
      locale: "tr-TR"
    });

    for (const code of codes) {
      try {
        funds[code] = await fetchFundInBrowser(page, code);
      } catch (e) {
        funds[code] = { ok: false, code, error: e && e.message ? e.message : String(e) };
        errors.push(`${code}: ${funds[code].error}`);
      }
    }

    const okCount = Object.values(funds).filter((x) => x && x.ok).length;

    res.status(okCount ? 200 : 502).json({
      ok: okCount > 0,
      source: "orka-vercel-browser-provider",
      startedAt,
      finishedAt: new Date().toISOString(),
      requested: codes,
      okCount,
      funds,
      errors
    });
  } catch (e) {
    res.status(500).json({
      ok: false,
      source: "orka-vercel-browser-provider",
      startedAt,
      finishedAt: new Date().toISOString(),
      requested: codes,
      error: e && e.message ? e.message : String(e),
      funds,
      errors
    });
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
};

module.exports.config = {
  maxDuration: 60
};
